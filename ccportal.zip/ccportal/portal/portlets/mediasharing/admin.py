from django.contrib import admin


from models import File, Directory

admin.site.register(File)
admin.site.register(Directory)