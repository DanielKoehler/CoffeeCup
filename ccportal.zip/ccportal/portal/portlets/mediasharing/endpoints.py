from django.shortcuts import render_to_response
from django.shortcuts import render

from django.template import RequestContext
from django.contrib.auth.decorators import permission_required
from django.views.decorators.csrf import csrf_exempt

from django.http import JsonResponse, HttpResponse
from django.core import serializers

from models import Directory, File

import json

from forms import DirectoryForm

# Create your views here. 
@permission_required('mediasharing.can_view')
def get_base(request):

    x = Directory.objects.filter(parent__isnull=True, owner__id=request.user.id)
    y = File.objects.filter(parent__isnull=True, owner__id=request.user.id)

    return JsonResponse({'name':None,'files':[z.get_client_inode() for z in x or y]}, safe=False)


# Create your views here. 
@permission_required('mediasharing.can_view')
def get_directory(request, objectId):
    return JsonResponse(Directory.objects.filter(id=objectId, owner__id=request.user.id).first().get_client_inode(), safe=False)

# Create your views here. 
@permission_required('mediasharing.can_create')
def post_directory(request):

    data = json.loads(request.body)

    if all (key in data for key in ("name", "parent")):

        name = data['name']
        parent = Directory.objects.get(id=data['parent']) if type(data['parent']) is int else None; 

        directory = Directory(name=name, parent=parent, owner=request.user, bytes=0)
        
        directory.save()

        return JsonResponse(directory.get_client_inode(), safe=False)

    return JsonResponse({'message':'Invalid post data..'}, status=400, safe=False)

@permission_required('mediasharing.can_view')
def get_object(request, objectId):

    objs = File.objects.filter(parent__isnull=True, owner__id=request.user.id)
    data = serializers.serialize("json", Directory.objects.filter(parent__isnull=True, owner__id=request.user.id))

    return JsonResponse(data, safe=False)
