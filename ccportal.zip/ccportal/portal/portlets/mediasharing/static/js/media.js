
var mediasharing = angular.module('mediasharing', [
'ngDialog',
'ngCookies'
]);

mediasharing.run( function run( $http, $cookies ){

    // For CSRF token compatibility with Django
    $http.defaults.headers.post['X-CSRFToken'] = $cookies['csrftoken'];
})

mediasharing.factory('hashFactory', function() {
    return {
        getRandom: function() {
            return Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1);
        }
    };
});

mediasharing.controller('MediaSharingCtrl', function($scope, $http, ngDialog, hashFactory) {

  $scope.workingPath = "";  

  $scope.directory = {};
  $scope.directory.files = [];

  $scope.uploadLimit = 20000;
  $scope.predicate = '-modified';
  $scope.editing = null;

  $scope.addFile = function() { 


    ngDialog.open({
        template: 'uploadForm',
    });

  };  

  $scope.navigate = function(objectId) {

    $http.get('ajax/directory/get/' + objectId, {}).

      success(function(data, status, headers, config) {
        // this callback will be called asynchronously
        // when the response is available
        if (status == 200){

          $scope.directory = data

        }

      }).
      error(function(data, status, headers, config) {
        // called asynchronously if an error occurs
        // or server returns response with an error status.
        ngDialog.open({
            template: '<h3>Something awful happened...</h3><p>The message the server sent back was: &ldquo;{{ngDialogData.message}}&rdquo;</p><p>Please contact your system admistrator if this error persists.</p>',
            plain: true,
            data: { message : data.message }
        });
    });
  }

  $scope.modify = function(id){
      $scope.editing = id;
  };

  $scope.update = function(id){
      $scope.editing = null;
  };

  $scope.addDirectory = function() { 
    
    var timestamp = new Date().getTime();
  
    $http.post('ajax/directory/post/', { 
      name: $scope.conflictSafeFileName('New Directory',  $scope.directory), 
      parent: $scope.workingPath
    }).
      success(function(data, status, headers, config) {
        // this callback will be called asynchronously
        // when the response is available
        if (status == 200){
          $scope.directory.files.push(data)
          $scope.modify(data.id)
        }

      }).
      error(function(data, status, headers, config) {
        // called asynchronously if an error occurs
        // or server returns response with an error status.
        ngDialog.open({
            template: '<h3>Something awful happened...</h3><p>The message the server sent back was: &ldquo;{{ngDialogData.message}}&rdquo;</p><p>Please contact your system admistrator if this error persists.</p>',
            plain: true,
            data: { message : data.message }
        });

    });  

  };

  $scope.conflictSafeFileName = function(name, directory){

    for (var file in directory.files){

      file = directory.files[file] 

      if(file.name == name){
        if (/^([A-Za-z0-9.-\s]+)-([0-9]+)$/.test(name)){
          var parts = name.split('-'); 
          parts[parts.length - 1] = parseInt(parts[parts.length - 1]) + 1;
          name = parts.join('-')
          return $scope.conflictSafeFileName(name, directory)
        } 
        return $scope.conflictSafeFileName(name + "-1", directory)
      }
    }

    return name

  }

  $scope.trash = function () {

  }


  $scope.navigate('');


});