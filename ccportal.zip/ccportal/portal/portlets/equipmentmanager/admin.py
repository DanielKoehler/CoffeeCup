from django.contrib import admin
from models import EquipmentItem, ItemHistory
# Register your models here.
admin.site.register(EquipmentItem)
admin.site.register(ItemHistory)